<!DOCTYPE html>
<html lang="en">
   <head>
      <style>
       @font-face{
         src: url(Poppins-Regular.ttf);
         font-family: Poppins;
       }

      .line1 {width:27%; background: #fff; position: fixed; left: 180px; top: 85px;}
       .LOGIN {
         color: #3e3e3e;
         text-align: center;
         position: relative;
         top: 25px;
         font-weight: bold;

       }

      </style>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title></title>
      <!-- Google Font: Source Sans Pro -->
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
      <!-- Font Awesome -->
      <link rel="stylesheet" href="asset/fontawesome/css/all.min.css">
      <!-- Theme style -->
      <link rel="stylesheet" href="asset/css/adminlte.min.css">
   </head>
   <body class="hold-transition login-page" style="background-color: #3e3e3e;">
       <img src="Lipa_City_Seal.svg" alt="DSMS Logo" width="90" height="90" style="position: fixed; left: 60px; top: 50px;">
       <h4 style="position: fixed; left: 180px; top: 65px; color: #FFFFFF; font-family: Poppins;">LIPA CITY GENERAL SERVICES OFFICE</h4>
       <h5 style="position: fixed; left: 180px; top: 105px; color: #FFFFFF; font-family: Poppins;">INVENTORY SYSTEM</h5>
        <hr class="line1"> <hr/>

      

      <div class="login-box" style="width: 30%; height: 65%; ">
         <!-- /.login-logo -->
         <div class="card card-outline" style="border-radius: 20px;">
            <div class="card-header" style="background-color: #670001; border-top-left-radius: 20px; border-top-right-radius: 20px; height: 40px; "> 
                </div>
               <img src="logologin.png" alt="DSMS Logo" width="150" height="150" style="display: block; margin-left: auto; margin-right: auto; margin-top: 30px; margin-bottom: 20px;">
                <div class="block_1"></div> <hr />
               
           
            <div class="card-body" >
               <form action="dashboard" method="post">
                  <div class="input-group mb-3" style="margin-left: 50px; margin-right: 50px;">
                     <input type="text" class="form-control" placeholder="Username" style="font-family: Poppins;">
                     <div class="input-group-append" style="margin-right: 50px; margin-bottom: 10px;">
                        <div class="input-group-text" style="margin-right: 50px; margin-bottom: 10px;">
                           <span class="fas fa-user" style="margin-top: 4px; margin-bottom: 4px;"></span>
                        </div>
                     </div>
                  </div>
                  <div class="input-group mb-3" style="margin-left: 50px; margin-right: 50px;">
                     <input type="password" class="form-control" placeholder="Password" style="font-family: Poppins;">
                     <div class="input-group-append" style="margin-right: 50px;">
                        <div class="input-group-text" style="margin-right: 50px;">
                           <span class="fas fa-lock"  ></span>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-6" style="display: block; margin-left: auto; margin-right: auto; margin-top: 10px; margin-bottom: 20px; width: 320px; ">
                        <button type="submit" class="btn btn-block" style="background-color: #45afbe; color: #ffffff; border-radius: 20px; font-family: Poppins; ">Login</button>
                     </div> 
                  </div>
               </form>
            </div>
            <!-- /.card-body -->
         </div>
         <!-- /.card -->
      </div>

   </body>
</html>